
#include "FPToolkit.c"
#include "M3d_matrix_tools.c"
#include <unistd.h>

// stickfigure initially designed as centered for a 400x400 window :
// not points 0 and 6 are farthest apart;
double x[13] = {175,225,225,300,225,225,250,200,150,175,175,100,175} ;
double y[13] = {300,300,250,225,225,200,100,175,100,200,225,225,250} ;
double z[13] = {0,0,0,0,0,0,0,0,0,0,0,0,0} ;
       // z[] values unimportant but should NOT be left uninitialized
       // as nan values WILL propagate through
int n = 13 ;



int main(int argc, char **argv) 
{

 if (argc != 3) {
    printf("usage : pgm_name   window_size  microseconds(30000)\n") ;
    exit(0) ;
 }
  
 double winsize = atoi(argv[1]) ;
 int u = atoi(argv[2]) ; 
 double center = winsize/2;

 G_init_graphics(winsize,winsize) ;

 // the original design was for a 400x400
 // window and the object is centered on 200,200
 // so we recenter it and make it larger
 // (you get to do this ... use the
 // M3d_make_movement_sequence_matrix  function :)

 // we want to: translate to origin, scale proportional to winsize/400, translate to center of screen: winsize/2

int mov_type[100];
double mov_val[100];
mov_type[0] = TX; mov_val[0] = -200;
mov_type[1] = TY; mov_val[1] = -200;
mov_type[2] = SX; mov_val[2] = winsize/400;
mov_type[3] = SY; mov_val[3] = winsize/400;
mov_type[4] = TX; mov_val[4] = center;
mov_type[5] = TY; mov_val[5] = center;



double move[4][4];
double movei[4][4];

M3d_make_movement_sequence_matrix(move, movei, 6, mov_type, mov_val);

M3d_mat_mult_points (x, y, z, move, x, y, z, n);

G_rgb(1,0,0);
G_fill_polygon(x, y, n);

int key = G_wait_key();

 // now make the movie the rotates and shrinks about the center :
// end with red circle

// to rotate and shrink we will translate to the origin, then scale and rotate and translate back
mov_type[0] = TX; mov_val[0] = -center;
mov_type[1] = TY; mov_val[1] = -center;
mov_type[2] = SX; mov_val[2] = .97;
mov_type[3] = SY; mov_val[3] = .97;
mov_type[4] = RZ; mov_val[4] = 7;
mov_type[5] = TX; mov_val[6] = center;
mov_type[6] = TY; mov_val[7] = center;

M3d_make_movement_sequence_matrix(move, movei, 7, mov_type, mov_val);

int q = -1;

while (sqrt(pow(x[0] - x[6], 2) + pow(y[0] - y[6], 2)) > 5) {
  G_rgb(1,1,1);
  G_clear();

  M3d_mat_mult_points (x, y, z, move, x, y, z, n);

  G_rgb(1,0,0);
  G_fill_polygon(x, y, n); 

  G_display_image();
  q = G_no_wait_key();
  usleep(u);
  int end = 0;
}

G_rgb(1,0,0);
G_fill_circle(center, center, winsize / 4); 

G_display_image();

key = G_wait_key();
}



