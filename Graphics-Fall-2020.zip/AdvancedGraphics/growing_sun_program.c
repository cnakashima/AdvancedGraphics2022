#include <stdio.h>
#include "FPToolkit.c"

int graphics(int width, int height, int frames, double delta_radius){
  double delta_radius_local = delta_radius;
  int frames_local = frames;
  double center[2];
  center[0] = width/2;
  center[1] = height/2; 
  char name[100];
  G_init_graphics (width,height) ;  // interactive graphics
  // clear the screen in a given color
  G_rgb (0, 0, 0) ; // black
  G_clear () ;
  double radius = 10;
  for (int i = 0; i < frames_local; i++){
    // Set color based on size relative to start and end
    G_rgb(1,(double) i/(frames_local-1),0);

    G_fill_circle(center[0], center[1], radius);

    int key ;   
    key =  G_wait_key() ; // pause so user can see results
    sprintf(name, "GrowingSun%04d.xwd",i);
    //   G_save_image_to_file("demo.xwd") ;
    G_save_image_to_file(name) ;
    radius += delta_radius_local;
   }
   
}

int main(int argc, char **argv) {
  // if wrong number of arguments print error
  if (argc != 5){
    printf("Usage: pgm_name window_width window_height number_of_frames delta_radius\n");
    exit(0);
  }
  // give input arguments names
  int window_width = atoi(argv[1]);
  int window_height = atoi(argv[2]);
  int number_of_frames = atoi(argv[3]);
  double delta_radius = atof(argv[4]);
  graphics(window_height, window_width, number_of_frames, delta_radius);
}

//start size 10

//transition from red 1,0,0 to yellow 1,1,0