#include "FPToolkit.c"


int click_and_save(double *x, double *y)
{
  double xy[2] ;
  int numpoints ;
  double xc,yc ;

  G_rgb(1, 0, 0) ; // red
  G_fill_rectangle(0,0,  40,20) ;

  numpoints = 0 ;
  while (0 == 0) {

     G_wait_click(xy) ;

     if ((xy[0] >= 0) && (xy[0] <= 40) && 
         (xy[1] >= 0) && (xy[1] <= 20))  { break ; }

     G_rgb(0.5, 0.5, 1) ;

     xc = xy[0] ;
     yc = xy[1] ;
     G_circle(xc, yc, 3) ;     

     x[numpoints] = xc ; y[numpoints] = yc ;  

     if (numpoints > 0) {
       G_line (x[numpoints-1],y[numpoints-1], x[numpoints],y[numpoints]) ;
     }

     numpoints++ ;
  }

  G_line (x[numpoints-1],y[numpoints-1], x[0],y[0]) ;
     
  return numpoints ;
}



void selection_sort (double *x, int n) 
{
  int i,s,j ;
  double tmp ;

  for (i = 0 ; i < n ; i++) {
    s = i ;
    for (j = i+1 ; j < n ; j++) {
      if (x[j] < x[s]) { s = j ; }
    }
    tmp = x[i] ; x[i] = x[s] ; x[s] = tmp ;
  }

}


void find_center(double centercoords[], double x[], double y[], int np){
  double sumx = 0;
  double sumy = 0;
  for (int i = 0; i < np; i++){
    sumx += x[i];
    sumy += y[i];
  }
  sumx /= np;
  sumy /= np;
  centercoords[0] = sumx;
  centercoords[1] = sumy;
}

void find_line(double abc[], double x1, double y1, double x2, double y2){
  abc[0] = y2 - y1;
  abc[1] = (-1)*(x2 - x1);
  abc[2] = abc[0]*(-1)*x1 + abc[1]*(-1)*y1;
}



int  is_point_inside_polygon (double P[2],
			      double *x, double *y, int n)
// return 1 if yes, 0 if no
{
  double center[2];
  find_center(center, x, y, n);
  double abc[3];
  // for each side in the clipper
  for (int j = 0; j < n; j++){
    if (j == 0){
      find_line(abc, x[n - 1], y[n - 1], x[j], y[j]);
    }
    else{
      find_line(abc, x[j - 1], y[j - 1], x[j], y[j]);
    }
    if (((center[0]*abc[0] + center[1]*abc[1] + abc[2])* (P[0]*abc[0] + P[1]*abc[1] + abc[2])) < 0){
      return 0;
    }
  }
  return 1;
}




int  main()
{
  int q ;
  double xp[1000],yp[1000] ;
  int np ;
  int k ;
  double P[2] ;
  int sig ;
  
  G_choose_repl_display();
  G_init_graphics (600,600) ;

  G_rgb(0,0,0) ;
  G_clear() ;

  np = click_and_save(xp,yp) ;
     
  do {
     G_wait_click(P) ;

     if ((P[0] >= 0) && (P[0] <= 40) && 
         (P[1] >= 0) && (P[1] <= 20))  { break ; }

     
     sig = is_point_inside_polygon (P, xp,yp,np) ;
     if (sig == 1) {
       G_rgb(0,1,0) ;
     } else {
       G_rgb(1,0,0) ;
     }
     
     G_fill_circle(P[0],P[1],2) ;

  } while (q != 'q') ;


}



