#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
  int score[100];
  char name [100][50];
  FILE *fp, *g;
  if (argc != 3){
    printf("Usage: pgm infile outfile\n");
    exit(0);
  }
  fp = fopen(argv[1], "r");
  if (fp == NULL){
    printf("Cannot open %s\n", argv[1]);
    exit(0);
  }
  int i = 0;
  int k = 0;
  while (1){
    k = fscanf(fp, "%d %s", &score[i], name[i]);
    if (k != 2){
      break;
    }
    i++;
  }
  // for (int i = 0; i < 5; i++){
  //   fscanf(fp, "%d %s", &score[i], name[i]);
  // }
  fclose(fp);
  g = fopen(argv[2], "w");
  if (g == NULL){
    printf("Cannot open %s\n", argv[2]);
    exit(0);
  }
  for (int j = i - 1; j >= 0; j--){
    fprintf(g, "%s %d \n", name[j], score[j]);
  }
  fclose(g);
}