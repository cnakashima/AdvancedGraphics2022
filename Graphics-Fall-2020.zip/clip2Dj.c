
#include "FPToolkit.c"



// the clipper polygon
double wx[100] = {200,520,320} ;
double wy[100] = {500,400,240} ;
int wn = 3 ;
double cwx,cwy ; // center of mass of clipper polygon



int  Clip_Polygon_Against_Line(
                  double a, double b, double c, 
                  double polyx[], double polyy[], int size,
                  double resx[], double resy[])
// Clip polygon against the line ax + by + c = 0,
// where ax + by + c < 0 is considered IN.
// Incoming poly defined in arrays  polyx, polyy  with numverts = size.
// Clipped result values are stored in arrays  resx, resy,
// The numverts of the clipped result is returned as value of the function.
{
  int num,i,j ;
  double x1,y1,x2,y2,x21,y21,den,t,xintsct,yintsct ;
  double v1,v2 ;
  
  num = 0 ;
  for (i = 0 ; i < size ; i++) {
     j = (i + 1) % size ;

     // load up segment to be clipped
     x1 = polyx[i] ; y1 = polyy[i] ;
     x2 = polyx[j] ; y2 = polyy[j] ;

     // clip line segment (x1,y1)-(x2,y2) against line
     v1 = a*x1 + b*y1 + c ;
     v2 = a*x2 + b*y2 + c ;
     
     if (v1 >= 0 && v2 >= 0) {
        // out to out, do nothing
     } else if (v1 < 0 && v2 < 0) {
        // in to in
        resx[num] = x2 ; resy[num] = y2 ; num++ ;
     } else {
        // one is in, the other out, so find the intersection

        x21 = x2 - x1 ; y21 = y2 - y1 ;
        den = a*x21 + b*y21 ;
        if (den == 0) continue ; // do nothing-should never happen

        // uses parametric equation for a line
        t = -(a*x1 + b*y1 + c)/den ;
        xintsct = x1 + t*x21 ;
        yintsct = y1 + t*y21 ;

        if (v1 < 0) { 
          // in to out
          resx[num] = xintsct ; resy[num] = yintsct ; num++ ;
        } else  {
          // out to in
          resx[num] = xintsct ; resy[num] = yintsct ; num++ ;
          resx[num] = x2      ; resy[num] = y2      ; num++ ;
        }

     }


  } // end for i

  return num ;  // return size of the result poly
}




int  Clip_Polygon_Against_Convex_Window (double px[],  double py[], int psize)
// notice that the clipper polygon is globally known
{
   double nx[100],ny[100],  a,b,c,  cwx,cwy ;
   int i,k,m ;


   // find center of mass of window
   cwx = 0.0 ; cwy = 0.0 ;
   for (k = 0 ; k < wn ; k++) {
     cwx += wx[k] ; cwy += wy[k] ;
   }
   cwx /= wn ; cwy /= wn ;



   // clip the polygon against each edge of the window
   for (k = 0 ; k < wn ; k++) {

      m = k+1 ; if (m == wn) { m = 0 ; }

      // ax + by + c = 0 is eqn of this window edge
      a = wy[m] - wy[k] ;
      b = wx[k] - wx[m] ;
      c = -(a*wx[k] + b*wy[k]) ;

      // but we need for ax + by + c < 0 to reflect "inside"
      if (a*cwx + b*cwy + c > 0) {
	a = -a ; b = -b ; c = -c ;
      }

      psize = Clip_Polygon_Against_Line (a,b,c,
                                         px,py,psize,
                                         nx,ny) ;

     // copy back in preparation for next pass
     for (i = 0 ; i < psize ; i++) {
       px[i] = nx[i] ;   py[i] = ny[i] ;  
     }

   } // end for k


   return psize ;
}




int main()
// this tests clipping of polygon to convex window
{
  // the polygon to be clipped
  double px[100] = {100,200,400,480} ;
  double py[100] = {150,100,200,500} ;
  int pn = 4 ;


  
  G_init_graphics (700, 700) ;
  G_rgb (0,0,0) ;
  G_clear() ;

  G_rgb(0,1,0) ;
  G_polygon(px,py,pn) ;

  G_rgb(1,0,0) ;
  G_polygon(wx,wy,wn) ;  
  
  pn =  Clip_Polygon_Against_Convex_Window (px, py, pn) ;

  G_rgb (1,1,0) ;
  G_fill_polygon(px,py,pn) ;
  G_wait_key() ;
}





