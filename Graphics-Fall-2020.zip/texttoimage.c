#include <stdio.h>
#include <stdlib.h>
#include "FPToolkit.c"

#define MAXPTS 9000
#define MAXPOLY 5000

int numpoints; 
double x[MAXPTS]; 
double y[MAXPTS];
int numpoly;
int psize[MAXPOLY];
int con[MAXPOLY][20]; //as many as 5000 polygons with up to 20 sides
double red[MAXPOLY], grn[MAXPOLY], blu[MAXPOLY];

void readxy(FILE *g){
  if (fscanf(g, "%i", &numpoints) != 1) (exit(0));
  for (int i = 0; i < numpoints; i++){
    fscanf(g, "%lf %lf", &x[i], &y[i]);
  }
}

void drawxy(){
  for (int i = 0; i < numpoints; i++){
    G_fill_circle(x[i], y[i], 5);
  }
}

void readpoly(FILE *g){
  if (fscanf(g, "%i", &numpoly) != 1) (exit(0));
  for (int i = 0; i < numpoly; i++){
    fscanf(g, "%i", &psize[i]);

    for (int j = 0; j < psize[i]; j++){
      fscanf(g, "%i", &con[i][j]);
    }
  }
}

void readcolors(FILE *g){
  for (int i = 0; i < numpoly; i++){
    fscanf(g, "%lf %lf %lf", &red[i], &grn[i], &blu[i]);
  }
}

void drawpoly(){
  double polyx[MAXPOLY];
  double polyy[MAXPOLY];
  for (int i = 0; i < numpoly; i++){
    for (int j = 0; j < psize[i]; j++){
      polyx[j] = x[con[i][j]];
      polyy[j] = y[con[i][j]];
    }
    G_rgb(red[i], grn[i], blu[i]);
    G_fill_polygon(polyx, polyy, psize[i]);
  }
}

int main(int argc, char** argv) {
  FILE *fp;
  if (argc != 2){
    printf("Usage: pgm infile\n");
    exit(0);
  }
  fp = fopen(argv[1], "r");
  if (fp == NULL){
    printf("Cannot open %s\n", argv[1]);
    exit(0);
  }
  readxy(fp);
  G_choose_repl_display();
  G_init_graphics(600, 600);
  // drawxy();
  readpoly(fp);
  readcolors(fp);
  drawpoly();
  G_display_image();
  G_wait_key();
}