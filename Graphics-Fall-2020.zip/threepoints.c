#include <stdio.h>
#include "FPToolkit.c"
#include "my.c"

int threepoints(double *u, double *v);

int main(void) {
  double u[100], v[100];
  int n;
  G_choose_repl_display();
  G_init_graphics(600, 600);
  threepoints(u, v);
  my_polygon(u, v, n);
  G_rgb(1, 1 ,1);
  G_fill_polygon(u, v, n);
  G_display_image();
  G_wait_key();
}

int threepoints(double *u, double *v){
  double interx[100], intery[100];
  double initx[2], inity[2];
  int n = 0;
  double coord[2];
  for (int i = 0; i < 2; i++){
    G_wait_click(coord);
      initx[i] = coord[0];
      inity[i] = coord[1];
      G_rgb(0, 0, 0);
      G_fill_circle(coord[0], coord[1], 3);
  }
  G_line(initx[1], inity[1], initx[0], inity[0]);
  if (inity[0] > inity[1]){
    double temp = inity[1];
    inity[1] = inity[0];
    inity[0] = temp;
    temp = initx[1];
    initx[1] = initx[0];
    initx[0] = temp;
  }
  while(1){
    G_wait_click(coord);
      u[n] = coord[0];
      v[n] = coord[1];
      G_rgb(0, 0, 0);
      G_fill_circle(u[n], v[n], 3);
      G_line(0, v[n], 600, v[n]);
      if (v[n] >= inity[0] && v[n] <= inity[1]){
        intery[n] = v[n];
        interx[n] = (((intery[n] - inity[0]) * (initx[1] - initx[0])) / (inity[1] - inity[0])) + (initx[0]);
        G_rgb(0, 1, 1);
        G_fill_circle(interx[n], intery[n], 5);
      }
      n++;
  }
}