#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "FPToolkit.c"
#include "M2d_matrix_toolsS.c"
#include "M3d_matrix_tools.c"

#define MAXPTS 9000
#define MAXPOLY 5000
#define SCREENSIZE 600
#define THETA .01
#define CENTERX 300
#define CENTERY 300
#define HALFANGLE 45 // in degrees


int numpoints[10]; 
double x[10][MAXPTS]; 
double y[10][MAXPTS];
double z[10][MAXPTS];
int numpoly[10];
int psize[10][MAXPOLY];
int con[10][MAXPOLY][20]; //as many as 5000 polygons with up to 20 sides
// double red[10][MAXPOLY], grn[10][MAXPOLY], blu[10][MAXPOLY];


void print_mat(double a[3][3]){
  for (int r = 0; r < 3; r++){
    for (int c = 0; c < 3; c++){
      printf("%lf ", a[r][c]);
    }
    printf("\n");
  }
}

void print_arrays(double a[4], double b[4]){
  for(int i = 0; i<4; i++){
    printf("%lf ", a[i]);
  }
  printf("\n");
  for(int i = 0; i<4; i++){
    printf("%lf ", b[i]);
  }
  printf("\n");
}


void rotate(int index, double t){
  // rotation matrix
  double R[3][3];
  M2d_make_rotation_radians(R, t);
  // translation from center of the screen to origin
  double T1[3][3];
  M2d_make_translation(T1, -CENTERX, -CENTERY);
  // translation from origin to center of screen
  double T2[3][3];
  M2d_make_translation(T2, CENTERX, CENTERY);
  // store resulting matrices in m
  double m[3][3];
  // m = T2*R*T1
  M2d_mat_mult(m, T2, R);
  M2d_mat_mult(m, m, T1);
  //  |x|       |x|
  //  |y| = m * |y|
  //  |1|       |1|
  M2d_mat_mult_points(x[index], y[index], m, x[index], y[index], numpoints[index]);
}


void transform(int index){

  // translate to the origin of xyz space
  // double T0[4][4];
  // M3d_make_translation(T0, -x[index][numpoints[index]], -y[index][numpoints[index]], -z[index][numpoints[index]]);
  // M3d_mat_mult_points(x[index], y[index], z[index], T0, x[index], y[index], z[index], numpoints[index]+1);

  double centerx = 0;
  double centery = 0;
  double scalar = 300 / tan(HALFANGLE*M_PI / 180);
  double T1[3][3];
  M2d_make_translation(T1, -centerx, -centery);
  // scaling matrix based on scalar
  double S[3][3];
  M2d_make_scaling(S, scalar, scalar);
  // translation to center of screen
  double T2[3][3];
  M2d_make_translation(T2, CENTERX, CENTERY);
  // M = T2 * S * T1
  double M[3][3];
  M2d_mat_mult(M, T2, S);
  M2d_mat_mult(M, M, T1);
  //  |x|       |x|
  //  |y| = M * |y|
  //  |1|       |1|
  
}

void readxyz(FILE *g, int index){
  int sumx = 0;
  int sumy = 0;
  int sumz = 0;
  if (fscanf(g, "%i", &numpoints[index]) != 1) (exit(0));
  for (int i = 0; i < numpoints[index]; i++){
    fscanf(g, "%lf %lf %lf", &x[index][i], &y[index][i], &z[index][i]);
    z[index][i] += 10;
    sumx+=x[index][i];
    sumy+=y[index][i];
    sumz+=z[index][i];
  }
  x[index][numpoints[index]] = sumx/numpoints[index];
  y[index][numpoints[index]] = sumy/numpoints[index];
  z[index][numpoints[index]] = sumz/numpoints[index];

  printf("%lf, %lf, %lf\n", x[index][numpoints[index]], y[index][numpoints[index]], z[index][numpoints[index]]);
}


void drawxy(int index){
  for (int i = 0; i < numpoints[index]; i++){
    G_fill_circle(x[index][i], y[index][i], 5);
  }
}

void readpoly(FILE *g, int index){
  if (fscanf(g, "%i", &numpoly[index]) != 1) (exit(0));
  for (int i = 0; i < numpoly[index]; i++){
    fscanf(g, "%i", &psize[index][i]);
    double center = 0;
  }
}


void drawpoly3d(double xp[], double yp[], double zp[], int n){
  for (int i = 0; i < n; i++){
    xp[i] = xp[i] / zp[i];
    yp[i] = yp[i] / zp[i];
  }
  double M[3][3];
  double S[3][3];
  M2d_make_translation(M, 300, 300);
  M2d_make_scaling(S, 300/tan(M_PI/4),  300/tan(M_PI/4));
  M2d_mat_mult(M, M, S);
  M2d_mat_mult_points(xp,yp, M, xp, yp, n);
  G_rgb(0, 0, 0);
  G_polygon(xp, yp, n);

}

void draw_single_object(int index){
  double xp[100];
  double yp[100];
  double zp[100];
  for (int i = 0; i < numpoly[index]; i++){
    for (int j = 0; j < psize[index][i]; j++){
      xp[j] = x[index][con[index][i][j]];
      yp[j] = y[index][con[index][i][j]];
      zp[j] = z[index][con[index][i][j]];
    }
    drawpoly3d(xp,yp,zp,psize[index][i]);
  }
}

void rotate3d(double rx[4][4], double ry[4][4], double rz[4][4], int image_index){
  int key = G_wait_key();
  switch (key){
    case ('x'): 
      M3d_mat_mult_points(x[image_index], y[image_index], z[image_index], rx, x[image_index], y[image_index], z[image_index], numpoints[image_index]);
    case ('y'): 
      M3d_mat_mult_points(x[image_index], y[image_index], z[image_index], ry, x[image_index], y[image_index], z[image_index], numpoints[image_index]);
    case ('z'): 
      M3d_mat_mult_points(x[image_index], y[image_index], z[image_index], rz, x[image_index], y[image_index], z[image_index], numpoints[image_index]);


  }

}

int main(int argc, char** argv) {
  int numobjects = argc;
  FILE *fp;
  if (argc < 2){
    printf("Usage: pgm infiles\n");
    exit(0);
  }
  for (int i = 1; i < argc; i++){
    fp = fopen(argv[i], "r");
    if (fp == NULL){
      printf("Cannot open %s\n", argv[i]);
      exit(0);
    }
    readxyz(fp, i - 1);
    readpoly(fp, i - 1);
    // readcolors(fp, i - 1);
    transform(i-1);
  }

  G_choose_repl_display();
  G_init_graphics(SCREENSIZE, SCREENSIZE);
  // drawxy();
  int current = 0;
  int input;
  int sign = 1;
  int action;
  double R3dx[4][4];
  M3d_make_x_rotation_cs(R3dx, cos(THETA/M_PI), sin(THETA/M_PI));
  double R3dy[4][4];
  M3d_make_y_rotation_cs(R3dy, cos(THETA/M_PI), sin(THETA/M_PI));
  double R3dz[4][4];
  M3d_make_z_rotation_cs(R3dz, cos(THETA/M_PI), sin(THETA/M_PI));


  while(1){
    //M3d_make_identity (V) ;
    int q = G_wait_key();
    if (q == 0){
      continue;
    }
    
    if (q == 'q') {
      exit(0) ;

    } else if (q == 'c') {
      sign = -sign ;

    } else if (q == 't') {
      action = q ;

    } else if (q == 'r') {
      action = q ;

    } else if (('0' <= q) && (q <= '9')) {
      int k = q - '0' ;  
      if (k < numobjects) {current = k ;}

    } else if ((q == 'x') && (action == 't')) {
      // translate along x in direction sign
    } else if ((q == 'y') && (action == 't')) {
      // translate along y in direction sign
    } else if ((q == 'z') && (action == 't')) {
      // translate along z in direction sign
    } else if ((q == 'x') && (action == 'r')) {
      // rotate along x in direction sign
    } else if ((q == 'y') && (action == 'r')) {
      // rotate along x in direction sign
    } else if ((q == 'z') && (action == 'r')) {
      // rotate along x in direction sign
    } else {
      printf("no action\n") ;
    }



    //M3d_mat_mult_points (x[current],y[current],z[current],  V, x[current],y[current],z[current],numpoints[current]+1) ;
      // the numpoints[onum]+1 is because we have stored the center
      // of the object at the arrays' end

    G_rgb(1,1,1) ; 
    G_clear() ;
    G_rgb(0,0,1) ;
    //    draw_all_objects() ;
    draw_single_object(current) ;
  }
}