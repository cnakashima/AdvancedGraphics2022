#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "FPToolkit.c"
#include "M2d_matrix_toolsS.c"

#define MAXPTS 9000
#define MAXPOLY 5000
#define SCREENSIZE 600
#define THETA .01
#define CENTERX 300
#define CENTERY 300

int numpoints[10]; 
double x[10][MAXPTS]; 
double y[10][MAXPTS];
int numpoly[10];
int psize[10][MAXPOLY];
int con[10][MAXPOLY][20]; //as many as 5000 polygons with up to 20 sides
double red[10][MAXPOLY], grn[10][MAXPOLY], blu[10][MAXPOLY];
// rotation matrix
double R[3][3];
// translation from center of the screen to origin
double T1[3][3];
// translation from origin to center of screen
double T2[3][3];
// store resulting matrices in m
double m[3][3];
int clippersides;
double clipperx[20];
double clippery[20];

// void rotate(int index, double t){
//   double oldx, oldy;
//   for (int i = 0; i < numpoints[index]; i++){
//     oldx = x[index][i] - CENTERX;
//     oldy = y[index][i] - CENTERY;
//     x[index][i] = ((oldx * cos(t)) - (oldy * sin(t))) + CENTERX;
//     y[index][i] = ((oldy * cos(t)) + (oldx * sin(t))) + CENTERY;
//   }
// }

void print_mat(double a[3][3]){
  for (int r = 0; r < 3; r++){
    for (int c = 0; c < 3; c++){
      printf("%lf ", a[r][c]);
    }
    printf("\n");
  }
}

void print_arrays(double a[4], double b[4]){
  for(int i = 0; i<4; i++){
    printf("%lf ", a[i]);
  }
  printf("\n");
  for(int i = 0; i<4; i++){
    printf("%lf ", b[i]);
  }
  printf("\n");
}

void find_center(double centercoords[], int poly_index, int image_index){
  // find center of image and length along x and y
  double maxx = -5000;
  double maxy = -5000;
  double minx = 5000;
  double miny = 5000;
  for (int i = 0; i < numpoints[image_index]; i++){
    if (maxx < x[image_index][i]){
      maxx = x[image_index][i];
    }
    if (maxy < y[image_index][i]){
      maxy = y[image_index][i];
    }
    if (minx > x[image_index][i]){
      minx = x[image_index][i];
    }
    if (miny > y[image_index][i]){
      miny = y[image_index][i];
    }
  }
  centercoords[0] = (maxx + minx)/2;
  centercoords[1] = (maxy + miny)/2;
}

void find_line(double abc[], double x1, double y1, double x2, double y2){
  abc[0] = y2 - y1;
  abc[1] = (-1)*(x2 - x1);
  abc[2] = abc[0]*(-1)*x1 + abc[1]*(-1)*y1;
}

void makepoint (double point[], int image_index, int poly_index, int point_index){
  point[0] = x[image_index][con[image_index][poly_index][point_index]];
  point[1] = y[image_index][con[image_index][poly_index][point_index]];
}


int inside_line(double center[], double abc[], int image_index, int l) {
  if (((center[0]*abc[0] + center[1]*abc[1] + abc[2])* (x[image_index][l]*abc[0] + y[image_index][l]*abc[1] + abc[2])) < 0){
    // false
    return 0;
  }
  // true
  return 1;
}

int inside_pair(double center[], double abc[][3], double point[]) {
  for (int m = 0; m < clippersides; m++){
    if (((center[0]*abc[m][0] + center[1]*abc[m][1] + abc[m][2])* (point[0]*abc[m][0] + point[1]*abc[m][1] + abc[m][2])) < 0){
      return 0;
    }
  }
  return 1;
}


int findintersection(double newpoint[], int image_index, int poly_index, int p1, int p2, double abcclip[]){
  double currentpt[2];
  makepoint(currentpt, image_index, poly_index, p1);
  double nextpt[2];
  makepoint(nextpt, image_index, poly_index, p2);
  double abcpoly[3];
  find_line(abcpoly, currentpt[0], currentpt[1], nextpt[0], nextpt[1]);
  double interx = (abcclip[2]*abcpoly[1] - abcpoly[2]*abcclip[1])/(abcpoly[0]*abcclip[1] - abcclip[0]*abcpoly[1]);
  double intery;
  if (abcclip[1] != 0) intery = ((-abcclip[0] * interx) - abcclip[2])/abcclip[1];
  else intery = ((-abcpoly[0] * interx) - abcpoly[2])/abcpoly[1];
  newpoint[0] = interx;
  newpoint[1] = intery;
}

void  Clip_Polygon_Against_Line(
                  double abc[], 
                  int index, int g)
// Clip polygon against the line ax + by + c = 0,
// Incoming poly defined in arrays  polyx, polyy  with numverts = size.
// Clipped result values are stored in arrays  resx, resy,
// The numverts of the clipped result is returned as value of the function.
{
  double resx[MAXPTS];
  double resy[MAXPTS];
  int rescon[MAXPOLY][20];
  int num = 0;

  int concounter[numpoly[index]];
  // find center
  double center[2];
  double maxx = -5000;
  double maxy = -5000;
  double minx = 5000;
  double miny = 5000;
  for (int i = 0; i < clippersides; i++){
    if (maxx < clipperx[i]){
      maxx = clipperx[i];
    }
    if (maxy < clippery[i]){
      maxy = clippery[i];
    }
    if (minx > clipperx[i]){
      minx = clipperx[i];
    }
    if (miny > clippery[i]){
      miny =  clippery[i];
    }
  }
  center[0] = (maxx + minx)/2;
  center[1] = (maxy + miny)/2;
 

  for (int i = 0; i < numpoly[index]; i++){
    concounter[i] = 0;
    for (int j = 0; j < psize[index][i]; j++){
      // if the current point is in add it to result
      if (inside_line(center, abc, index, con[index][i][j]) == 1){
        // add the point to the num index in point arrays
        resx[num] = x[index][con[index][i][j]];
        resy[num] = y[index][con[index][i][j]];
        // store index of this point in the next polygon constructor
        rescon[i][concounter[i]] = num;
        // increment both
        num++;
        concounter[i]++;
      }
      // if current point is not in find out if either the previous or next were in
      else{
        double newpoint[2];
        // check if this is the first or the last point
        if (j == 0){
          // check if the last point is in
          if (inside_line(center, abc, index, con[index][i][psize[index][i] - 1]) == 1){
            findintersection(newpoint, index, i, psize[index][i] - 1, j, abc);
            // add the point to the num index in point arrays
            resx[num] = newpoint[0];
            resy[num] = newpoint[1];
            // store index of this point in the next polygon constructor
            rescon[i][concounter[i]] = num;
            // increment both
            num++;
            concounter[i]++;
          }
        }
        else {
          if (inside_line(center, abc, index, con[index][i][j-1]) == 1){
            findintersection(newpoint, index, i, j - 1, j, abc);
            // add the point to the num index in point arrays
            resx[num] = newpoint[0];
            resy[num] = newpoint[1];
            // store index of this point in the next polygon constructor
            rescon[i][concounter[i]] = num;
            // increment both
            num++;
            concounter[i]++;
          }
        }
        if (j == psize[index][i] - 1){
          if (inside_line(center, abc, index, con[index][i][0]) == 1){
            findintersection(newpoint, index, i, 0, j, abc);
            // add the point to the num index in point arrays
            resx[num] = newpoint[0];
            resy[num] = newpoint[1];
            // store index of this point in the next polygon constructor
            rescon[i][concounter[i]] = num;
            // increment both
            num++;
            concounter[i]++;
          }
        }
        else {
          // if the next one is in find the intersection
          if (inside_line(center, abc, index, con[index][i][j+1])  == 1){
            findintersection(newpoint, index, i, j, j + 1, abc);
            // add the point to the num index in point arrays
            resx[num] = newpoint[0];
            resy[num] = newpoint[1];
            // store index of this point in the next polygon constructor
            rescon[i][concounter[i]] = num;
            // increment both
            num++;
            concounter[i]++;
          }
        }
      }
    }
  }

  for (int i = 0; i < num; i++){
    x[index][i] = resx[i];
    y[index][i] = resy[i];
  }
  numpoints[index] = num;
  for (int i = 0; i < numpoly[index]; i++){
    for (int j = 0; j < concounter[i]; j++){
      con[index][i][j] = rescon[i][j];
    }
    psize[index][i] = concounter[i];
  }


  // // check all points
  // for (int z = 0; z < numpoints[index]; z++){
  //   // printf("(%lf, %lf)\n", x[index][z], y[index][z]);
  //   G_fill_circle(x[index][z], y[index][z], 8);
  // }
  // // horizontal line
  // if (abc[0] == 0){
  //   G_line(-1, -abc[2]/abc[1], 700, -abc[2]/abc[1]);
  // }
  // if (abc[1] == 0){
  //   G_line(-abc[2]/abc[0], -1, -abc[2]/abc[0], 700);
  // }
  // go through all points
  // look for cross-overs
  // replace them with intersection across clipper line
  // if a point does not have an edge that intersects the line then remove it
}

void clip(int image_index){

  double abc[clippersides][3];
  // for each side in the clipper find the equation of the line
  find_line(abc[0], clipperx[clippersides - 1], clippery[clippersides - 1], clipperx[0], clippery[0]);
  for (int j = 1; j < clippersides; j++){
    find_line(abc[j], clipperx[j- 1], clippery[j - 1], clipperx[j], clippery[j]);
  }
  
  // clip against each line
  for (int i = 0; i < clippersides; i++){
    Clip_Polygon_Against_Line(abc[i], image_index, i);
  }
}


void rotate(int index){
  // store resulting matrices in m
  double m[3][3];
  // m = T2*R*T1
  M2d_mat_mult(m, T2, R);
  M2d_mat_mult(m, m, T1);
  //  |x|       |x|
  //  |y| = m * |y|
  //  |1|       |1|
  M2d_mat_mult_points(x[index], y[index], m, x[index], y[index], numpoints[index]);
}


// void transform(int index){
//   // double polyx[MAXPOLY];
//   // double polyy[MAXPOLY];
//   // int sizex, sizey = 0;
//   double maxx = -5000;
//   double maxy = -5000;
//   double minx = 5000;
//   double miny = 5000;
//   for (int i = 0; i < numpoints[index]; i++){
//     // polyx[j] = x[index][con[index][i][j]];
//     // polyy[j] = y[index][con[index][i][j]];
//     // sizex ++;
//     // sizey++;
//     if (maxx < x[index][i]){
//       maxx = x[index][i];
//     }
//     if (maxy < y[index][i]){
//       maxy = y[index][i];
//     }
//     if (minx > x[index][i]){
//       minx = x[index][i];
//     }
//     if (miny > y[index][i]){
//       miny = y[index][i];
//     }
//   }
//   // double maxx = findmax(polyx, sizex);
//   // double maxy = findmax(polyy, sizey);
//   // double minx = findmin(polyx, sizex);
//   // double miny = findmin(polyy, sizey);
//   double centerx = (maxx + minx)/2;
//   double centery = (maxy + miny)/2;
//   double lengthx = maxx - minx;
//   double lengthy = maxy - miny;
//   for (int i = 0; i < numpoints[index]; i++){
//       x[index][i] -= centerx;
//       y[index][i] -= centery;
//       if (lengthx > lengthy){
//         x[index][i] *= SCREENSIZE/lengthx;
//         y[index][i] *= SCREENSIZE/lengthx;
//       }
//       else{
//         y[index][i] *= SCREENSIZE/lengthy;
//         x[index][i] *= SCREENSIZE/lengthy;
//       }
//       x[index][i] += SCREENSIZE/2;
//       y[index][i] += SCREENSIZE/2;
//   }
// }

void transform(int index){
  // find center of image and length along x and y
  double maxx = -5000;
  double maxy = -5000;
  double minx = 5000;
  double miny = 5000;
  for (int i = 0; i < numpoints[index]; i++){
    if (maxx < x[index][i]){
      maxx = x[index][i];
    }
    if (maxy < y[index][i]){
      maxy = y[index][i];
    }
    if (minx > x[index][i]){
      minx = x[index][i];
    }
    if (miny > y[index][i]){
      miny = y[index][i];
    }
  }
  double centerx = (maxx + minx)/2;
  double centery = (maxy + miny)/2;
  double lengthx = maxx - minx;
  double lengthy = maxy - miny;
  double scalar;
  // create a scalar based on lengthx or lengthy whichever is greater
  if (lengthx > lengthy){
    scalar = SCREENSIZE / lengthx;
  }
  else{
    scalar = SCREENSIZE / lengthy;
  }
  // translation to origin
  double T1[3][3];
  M2d_make_translation(T1, -centerx, -centery);
  // scaling matrix based on scalar
  double S[3][3];
  M2d_make_scaling(S, scalar, scalar);
  // translation to center of screen
  double T2[3][3];
  M2d_make_translation(T2, CENTERX, CENTERY);
  // M = T2 * S * T1
  double M[3][3];
  M2d_mat_mult(M, T2, S);
  M2d_mat_mult(M, M, T1);
  //  |x|       |x|
  //  |y| = M * |y|
  //  |1|       |1|
  M2d_mat_mult_points(x[index], y[index], M, x[index], y[index], numpoints[index]);
}

void readxy(FILE *g, int index){
  if (fscanf(g, "%i", &numpoints[index]) != 1) (exit(0));
  for (int i = 0; i < numpoints[index]; i++){
    fscanf(g, "%lf %lf", &x[index][i], &y[index][i]);
  }
}

void drawxy(int index){
  for (int i = 0; i < numpoints[index]; i++){
    G_fill_circle(x[index][i], y[index][i], 5);
  }
}

void readpoly(FILE *g, int index){
  if (fscanf(g, "%i", &numpoly[index]) != 1) (exit(0));
  for (int i = 0; i < numpoly[index]; i++){
    fscanf(g, "%i", &psize[index][i]);

    for (int j = 0; j < psize[index][i]; j++){
      fscanf(g, "%i", &con[index][i][j]);
    }
  }
}

void readcolors(FILE *g, int index){
  for (int i = 0; i < numpoly[index]; i++){
    fscanf(g, "%lf %lf %lf", &red[index][i], &grn[index][i], &blu[index][i]);
  }
}

void drawpoly(int index){
  double polyx[MAXPOLY];
  double polyy[MAXPOLY];
  for (int i = 0; i < numpoly[index]; i++){
    for (int j = 0; j < psize[index][i]; j++){
      polyx[j] = x[index][con[index][i][j]];
      polyy[j] = y[index][con[index][i][j]];
    }
    G_rgb(red[index][i], grn[index][i], blu[index][i]);
    G_fill_polygon(polyx, polyy, psize[index][i]);
  }
}

void click_and_save(){
  int n = 0;
  double coord[2];
  while(1){
    G_wait_click(coord);
    if (coord[0] <= 50 && coord[1] <= 50){
      clippersides = n;
      return;
    }
    else{
      clipperx[n] = coord[0];
      clippery[n] = coord[1];
      G_rgb(0, 0, 0);
      G_fill_circle(coord[0], coord[1], 3);
      if (n > 0){
        G_line(clipperx[n], clippery[n], clipperx[n - 1], clippery[n - 1]);
      }
      n++;
    }
  }
}


int main(int argc, char** argv) {
  FILE *fp;
  if (argc < 2){
    printf("Usage: pgm infiles\n");
    exit(0);
  }
  for (int i = 1; i < argc; i++){
    fp = fopen(argv[i], "r");
    if (fp == NULL){
      printf("Cannot open %s\n", argv[i]);
      exit(0);
    }
    readxy(fp, i - 1);
    readpoly(fp, i - 1);
    readcolors(fp, i - 1);
    transform(i - 1);
  }

  G_choose_repl_display();
  G_init_graphics(SCREENSIZE, SCREENSIZE);
  // drawxy();
  int current = 0;
  int key;
  int input;
  // rotation matrix
M2d_make_rotation_radians(R, THETA * M_PI);
// translation from center of the screen to origin
M2d_make_translation(T1, -CENTERX, -CENTERY);
// translation from origin to center of screen
M2d_make_translation(T2, CENTERX, CENTERY);
// store resulting matrices in m
double m[3][3];
  while(1){
    key = G_wait_key();
    printf("%i\n", key);
    if (key =='q'){
      return 0;
    }
    if ('0' <= key && key <= '9'){
      input = key - '0';
      if (input < argc - 1){
        current = input;
        drawpoly(current);
      }
    }
    if (key == 'r' && current > -1){
      rotate(current);
    }
    if (key == 'c' && current > -1){
      click_and_save();
      clip(current);
    }
    G_rgb(1, 1, 1);
      G_clear();
      drawpoly(current);
      G_display_image();
    
  }
}