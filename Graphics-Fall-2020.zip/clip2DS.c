#include  "FPToolkit.c"


// the clipper polygon
double wx[100] = {200,520,320} ;
double wy[100] = {500,400,240} ;
int wn = 3 ;
double cwx,cwy ; // center of mass of clipper polygon



int  Clip_Polygon_Against_Line(
                  double a, double b, double c, 
                  double polyx[], double polyy[], int size,
                  double resx[], double resy[])
// Clip polygon against the line ax + by + c = 0,
// Incoming poly defined in arrays  polyx, polyy  with numverts = size.
// Clipped result values are stored in arrays  resx, resy,
// The numverts of the clipped result is returned as value of the function.
{
  int num ;
  
  // lots of work to do here ...

  return num ;  // return size of the result poly
}






int  Clip_Polygon_Against_Convex_Window (double px[],  double py[], int psize)
// notice that the clipper polygon is globally known
{
   int k ;

  double centercoords[2];
  double maxx = -5000;
  double maxy = -5000;
  double minx = 5000;
  double miny = 5000;
  for (int i = 0; i < psize; i++){
    if (maxx < px[i]){
      maxx = px[i];
    }
    if (maxy < py[i]){
      maxy = py[i];
    }
    if (minx > px[i]){
      minx = px[i];
    }
    if (miny > py[i]){
      miny = py[i];
    }
  }

  centercoords[0] = (maxx + minx)/2;
  centercoords[1] = (maxy + miny)/2;

   
   // now ...
   for (k = 0 ; k < wn ; k++) {

     // clip polygon against each edge  of the clipper window

   } 


   return psize ; // very possibly a different value than the one
   // that came in
}








int main()
// this tests clipping of polygon to convex window
{
  // the polygon to be clipped
  double px[100] = {100,200,400,480} ;
  double py[100] = {150,100,200,500} ;
  int pn = 4 ;


  
  G_init_graphics (700, 700) ;
  G_rgb (0,0,0) ;
  G_clear() ;

  G_rgb(0,1,0) ;
  G_polygon(px,py,pn) ;

  G_rgb(1,0,0) ;
  G_polygon(wx,wy,wn) ;  
  
  pn =  Clip_Polygon_Against_Convex_Window (px, py, pn) ;

  G_rgb (1,1,0) ;
  G_fill_polygon(px,py,pn) ;
  G_wait_key() ;
}





