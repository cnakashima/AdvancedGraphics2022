#include <stdio.h>
#include <math.h>
#include "FPToolkit.c"

void printcoords(double x[], double y[], int n){
  printf("[");
  for (int i = 0; i < n; i++){
    printf(" (%f, %f) ", x[i], y[i]);
  }
  printf("]\n");
}

int my_polygon(double *u, double *v, int vert){
  for(int i = 0; i < vert; i++){
    if (i + 1 == vert){
      G_line(u[i], v[i], u[0], v[0]);
    }
    else{
      G_line(u[i], v[i], u[i+1], v[i+1]);
    }
  }
}


void selection_sort(double x[], double y[], int n)
{
  for (int i = 0; i < n; i++){
    int index = i;
    for (int j = i + 1; j < n; j++){
      if ((x[j] + y[j]) != 0 && x[j] < x[index]){
        index = j;
      }
    }
    double temp = x[i];
    x[i] = x[index];
    x[index] = temp;
    temp = y[i];
    y[i] = y[index];
    y[index] = temp;
  }
}

int find_vertex_intersect(double interx[], double intery[], int count, double u[], double v[], int n, double line){
  if (v[0] == line && ((v[0] - v[1]) > 0) != ((v[0] - v[n - 1]) > 0)){
    interx[count] = u[0];
    intery[count] = v[0];
    count++;
  }
  for (int i = 1; i < n - 1; i++){
    if (v[i] == line && ((v[i] - v[i + 1]) > 0) != ((v[i] - v[i - 1]) > 0)){
      interx[count] = u[i];
      intery[count] = v[i];
      count++;
    }
  }
  if (v[n - 1] == line && ((v[n - 1] - v[0]) > 0) != ((v[n - 1] - v[n - 2]) > 0)){
    interx[count] = u[n - 1];
    intery[count] = v[n - 1];
    count++;
  }
  return count;
}

int find_intersect(double *intersection, double *u, double *v, int i1, int i2, double line){
  double x1 = u[i1];
  double x2 = u[i2];
  double y1 = v[i1];
  double y2 = v[i2];
  if (y1 > y2){
    double temp = x2;
    x2 = x1;
    x1 = temp;
    temp = y2;
    y2 = y1;
    y1 = temp;
  }
  if (line > y1 && line < y2){
    intersection[1] = line;
    intersection[0] = (((intersection[1] - y1) *(x2 - x1)) / (y2 - y1)) + (x1);
    return 1;
  }
  return 0;
}

int my_fill_polygon(double *u, double *v, int vert){
  for (int y = 0; y < 600; y++){
    int h_line = y;
    double intery[100];
    double interx[100];
    int intercount = 0;
    for (int i = 0; i < vert; i++){
      double intersect[2];
      if (i + 1 == vert){
        intercount += find_intersect(intersect, u, v, 0, i, h_line);
      }
      else{
        intercount += find_intersect(intersect, u, v, i, i+1, h_line);
      }
      interx[intercount - 1] = intersect[0];
      intery[intercount - 1] = intersect[1];
    }
    intercount = find_vertex_intersect(interx, intery, intercount, u, v, vert, h_line);
    selection_sort(interx, intery, intercount);
    for (int i = 0; i < vert - 1; i++){
      if (i % 2 == 0){
        G_line(interx[i], intery[i], interx[i+1], intery[i+1]);
      }
    }
  }
}

int grid(double x, double y){
  G_rgb(.6, .7, 1);
  for (int i = 0; i < 600; i += 10){
    G_line(i, 0, i, y);
  }
  for (int i = 0; i < 600; i += 10){
    G_line(0, i, x, i);
  }
}

int click_and_save(double *u, double *v){
  int n = 0;
  double coord[2];
  while(1){
    G_wait_click(coord);
    if (coord[0] <= 50 && coord[1] <= 50){
      return n;
    }
    else{
      u[n] = coord[0];
      v[n] = coord[1];
      G_rgb(0, 0, 0);
      G_fill_circle(coord[0], coord[1], 3);
      if (n > 0){
        G_line(u[n], v[n], u[n - 1], v[n - 1]);
      }
      n++;
    }
  }
}

int click_and_save_grid(double *u, double *v){
  grid(600, 600);
  int n = 0;
  double coord[2];
  while(1){
    G_wait_click(coord);
    if (coord[0] <= 50 && coord[1] <= 50){
      return n;
    }
    else{
      u[n] = round(coord[0] / 10) * 10;
      v[n] = round(coord[1] / 10) * 10;
      G_rgb(0, 0, 0);
      G_fill_circle(u[n], v[n], 5);
      if (n > 0){
        G_line(u[n], v[n], u[n - 1], v[n - 1]);
      }
      n++;
    }
  }
}

int click_and_save_grid_do_while(double *u, double *v){
  grid(600, 600);
  int n = 0;
  double coord[2];
  do{
    G_wait_click(coord);
    u[n] = round(coord[0] / 10) * 10;
    v[n] = round(coord[1] / 10) * 10;
    G_rgb(0, 0, 0);
    G_fill_circle(u[n], v[n], 5);
    if (n > 0){
      G_line(u[n], v[n], u[n - 1], v[n - 1]);
    }
    n++;
  } while(coord[0] > 50 || coord[1] > 50);
  return n - 1;
}