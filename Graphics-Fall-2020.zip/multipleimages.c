#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "FPToolkit.c"
#include "M2d_matrix_toolsS.c"

#define MAXPTS 9000
#define MAXPOLY 5000
#define SCREENSIZE 600
#define THETA .01
#define CENTERX 300
#define CENTERY 300

int numpoints[10]; 
double x[10][MAXPTS]; 
double y[10][MAXPTS];
int numpoly[10];
int psize[10][MAXPOLY];
int con[10][MAXPOLY][20]; //as many as 5000 polygons with up to 20 sides
double red[10][MAXPOLY], grn[10][MAXPOLY], blu[10][MAXPOLY];

// void rotate(int index, double t){
//   double oldx, oldy;
//   for (int i = 0; i < numpoints[index]; i++){
//     oldx = x[index][i] - CENTERX;
//     oldy = y[index][i] - CENTERY;
//     x[index][i] = ((oldx * cos(t)) - (oldy * sin(t))) + CENTERX;
//     y[index][i] = ((oldy * cos(t)) + (oldx * sin(t))) + CENTERY;
//   }
// }

void print_mat(double a[3][3]){
  for (int r = 0; r < 3; r++){
    for (int c = 0; c < 3; c++){
      printf("%lf ", a[r][c]);
    }
    printf("\n");
  }
}

void print_arrays(double a[4], double b[4]){
  for(int i = 0; i<4; i++){
    printf("%lf ", a[i]);
  }
  printf("\n");
  for(int i = 0; i<4; i++){
    printf("%lf ", b[i]);
  }
  printf("\n");
}


void rotate(int index, double t){
  // rotation matrix
  double R[3][3];
  M2d_make_rotation_radians(R, t);
  // translation from center of the screen to origin
  double T1[3][3];
  M2d_make_translation(T1, -CENTERX, -CENTERY);
  // translation from origin to center of screen
  double T2[3][3];
  M2d_make_translation(T2, CENTERX, CENTERY);
  // store resulting matrices in m
  double m[3][3];
  // m = T2*R*T1
  M2d_mat_mult(m, T2, R);
  M2d_mat_mult(m, m, T1);
  //  |x|       |x|
  //  |y| = m * |y|
  //  |1|       |1|
  M2d_mat_mult_points(x[index], y[index], m, x[index], y[index], numpoints[index]);
}


// void transform(int index){
//   // double polyx[MAXPOLY];
//   // double polyy[MAXPOLY];
//   // int sizex, sizey = 0;
//   double maxx = -5000;
//   double maxy = -5000;
//   double minx = 5000;
//   double miny = 5000;
//   for (int i = 0; i < numpoints[index]; i++){
//     // polyx[j] = x[index][con[index][i][j]];
//     // polyy[j] = y[index][con[index][i][j]];
//     // sizex ++;
//     // sizey++;
//     if (maxx < x[index][i]){
//       maxx = x[index][i];
//     }
//     if (maxy < y[index][i]){
//       maxy = y[index][i];
//     }
//     if (minx > x[index][i]){
//       minx = x[index][i];
//     }
//     if (miny > y[index][i]){
//       miny = y[index][i];
//     }
//   }
//   // double maxx = findmax(polyx, sizex);
//   // double maxy = findmax(polyy, sizey);
//   // double minx = findmin(polyx, sizex);
//   // double miny = findmin(polyy, sizey);
//   double centerx = (maxx + minx)/2;
//   double centery = (maxy + miny)/2;
//   double lengthx = maxx - minx;
//   double lengthy = maxy - miny;
//   for (int i = 0; i < numpoints[index]; i++){
//       x[index][i] -= centerx;
//       y[index][i] -= centery;
//       if (lengthx > lengthy){
//         x[index][i] *= SCREENSIZE/lengthx;
//         y[index][i] *= SCREENSIZE/lengthx;
//       }
//       else{
//         y[index][i] *= SCREENSIZE/lengthy;
//         x[index][i] *= SCREENSIZE/lengthy;
//       }
//       x[index][i] += SCREENSIZE/2;
//       y[index][i] += SCREENSIZE/2;
//   }
// }

void transform(int index){
  // find center of image and length along x and y
  double maxx = -5000;
  double maxy = -5000;
  double minx = 5000;
  double miny = 5000;
  for (int i = 0; i < numpoints[index]; i++){
    if (maxx < x[index][i]){
      maxx = x[index][i];
    }
    if (maxy < y[index][i]){
      maxy = y[index][i];
    }
    if (minx > x[index][i]){
      minx = x[index][i];
    }
    if (miny > y[index][i]){
      miny = y[index][i];
    }
  }
  double centerx = (maxx + minx)/2;
  double centery = (maxy + miny)/2;
  double lengthx = maxx - minx;
  double lengthy = maxy - miny;
  double scalar;
  // create a scalar based on lengthx or lengthy whichever is greater
  if (lengthx > lengthy){
    scalar = SCREENSIZE / lengthx;
  }
  else{
    scalar = SCREENSIZE / lengthy;
  }
  // translation to origin
  double T1[3][3];
  M2d_make_translation(T1, -centerx, -centery);
  // scaling matrix based on scalar
  double S[3][3];
  M2d_make_scaling(S, scalar, scalar);
  // translation to center of screen
  double T2[3][3];
  M2d_make_translation(T2, CENTERX, CENTERY);
  // M = T2 * S * T1
  double M[3][3];
  M2d_mat_mult(M, T2, S);
  M2d_mat_mult(M, M, T1);
  //  |x|       |x|
  //  |y| = M * |y|
  //  |1|       |1|
  M2d_mat_mult_points(x[index], y[index], M, x[index], y[index], numpoints[index]);
}

void readxy(FILE *g, int index){
  if (fscanf(g, "%i", &numpoints[index]) != 1) (exit(0));
  for (int i = 0; i < numpoints[index]; i++){
    fscanf(g, "%lf %lf", &x[index][i], &y[index][i]);
  }
}

void drawxy(int index){
  for (int i = 0; i < numpoints[index]; i++){
    G_fill_circle(x[index][i], y[index][i], 5);
  }
}

void readpoly(FILE *g, int index){
  if (fscanf(g, "%i", &numpoly[index]) != 1) (exit(0));
  for (int i = 0; i < numpoly[index]; i++){
    fscanf(g, "%i", &psize[index][i]);

    for (int j = 0; j < psize[index][i]; j++){
      fscanf(g, "%i", &con[index][i][j]);
    }
  }
}

void readcolors(FILE *g, int index){
  for (int i = 0; i < numpoly[index]; i++){
    fscanf(g, "%lf %lf %lf", &red[index][i], &grn[index][i], &blu[index][i]);
  }
}

void drawpoly(int index){
  double polyx[MAXPOLY];
  double polyy[MAXPOLY];
  for (int i = 0; i < numpoly[index]; i++){
    for (int j = 0; j < psize[index][i]; j++){
      polyx[j] = x[index][con[index][i][j]];
      polyy[j] = y[index][con[index][i][j]];
    }
    G_rgb(red[index][i], grn[index][i], blu[index][i]);
    G_fill_polygon(polyx, polyy, psize[index][i]);
  }
}

int main(int argc, char** argv) {
  FILE *fp;
  if (argc < 2){
    printf("Usage: pgm infiles\n");
    exit(0);
  }
  for (int i = 1; i < argc; i++){
    fp = fopen(argv[i], "r");
    if (fp == NULL){
      printf("Cannot open %s\n", argv[i]);
      exit(0);
    }
    readxy(fp, i - 1);
    readpoly(fp, i - 1);
    readcolors(fp, i - 1);
    transform(i - 1);
  }

  G_choose_repl_display();
  G_init_graphics(SCREENSIZE, SCREENSIZE);
  // drawxy();
  int current = 0;
  int key;
  int input;
  while(1){
    key = G_wait_key();
    if (key =='q'){
      return 0;
    }
    if ('0' <= key && key <= '9'){
      input = key - '0';
      if (input < argc - 1){
        current = input;
      }
    }
    if (key == 'r' && current > -1){
      rotate(current, THETA * M_PI);
    }
    G_rgb(1, 1, 1);
      G_clear();
      drawpoly(current);
      G_display_image();
    
  }
}