#include <stdio.h>
#include "FPToolkit.c"
#include "my.c"

int main(void) {
  double u[100], v[100];
  int n;
  G_choose_repl_display();
  G_init_graphics(600, 600);
  G_rgb(0.0, 1, 0.0);
  G_fill_rectangle(0, 0, 50, 50);
  n = click_and_save_grid(u, v);
  //n = click_and_save(u, v);
  my_polygon(u, v, n);
  G_rgb(1, 0 ,0);
  my_fill_polygon(u, v, n);
  G_display_image();
  G_wait_key();
}