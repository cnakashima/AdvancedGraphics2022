#include <stdio.h>


void print_array(double x[], int n)
{
  int k ;

  for (k = 0 ; k < n ; k++) {
    printf("%d  :  %lf\n",k,x[k]) ;
  }

}


void selection_sort(double x[], int n)
{
  for (int i = 0; i < n; i++){
    int index = i;
    for (int j = i + 1; j < n; j++){
      if (x[j] < x[index]){
        index = j;
      }
    }
    double temp = x[i];
    x[i] = x[index];
    x[index] = temp;
  }
}






int main()
{
  double u[100] = {50, 40.5, 80, 30, 20, 60} ;

  printf("Before :\n") ;
  print_array(u,6) ;

  selection_sort(u,6) ;

  printf("After :\n") ;  
  print_array(u,6) ;  
}
