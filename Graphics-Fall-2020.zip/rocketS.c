#include "FPToolkit.c"
#include "M2d_matrix_toolsS.c"

void draw_rocket(double A[], double B[], double rx[], double ry[], double rheight, double rlength, double center[]){
  // double Mid[2];
  // Mid[0] = (A[0] + B[0])/2;
  // Mid[1] = (A[1] + B[1])/2;
  // double T1[3][3];
  // M2d_make_translation(T1, -center[0], -center[1]);
  double T2[3][3];
  M2d_make_translation(T2, A[0], A[1]);
  double S[3][3];
  double length = sqrt(((B[0]- A[0])*(B[0]- A[0])) + ((B[1]- A[1])*(B[1]- A[1])));
  M2d_make_scaling(S, length/rheight, length/rheight);
  double R[3][3];
  M2d_make_rotation_radians(R, atan2l(B[1] - A[1], B[0] - A[0]) - (M_PI / 2));
  double M[3][3];
  // M2d_mat_mult(M, S, T1);
  M2d_mat_mult(M, R, S);
  M2d_mat_mult(M, T2, M);
  M2d_mat_mult_points(rx, ry, M, rx, ry, 8);
}

int main()
{
  G_choose_repl_display();
  G_init_graphics(600, 600) ;
  // rocket
  double rx[8] = {0, 16,  7,  7,  0, -7, -7, -16 } ;
  double ry[8] = {0,  0, 15, 35, 50, 35, 15,   0 } ;

  double maxx = -1000;
  double minx = 1000;
  double maxy = -1000;
  double miny = 1000;
  for (int i = 0; i < 8; i++){
    if (rx[i] > maxx){
      maxx = rx[i];
    }
    if (rx[i] < minx){
      minx = rx[i];
    }
    if (ry[i] > maxy){
      maxy = ry[i];
    }
    if (ry[i] < miny){
      miny = ry[i];
    }
  }
  double center[2];
  center[0] = (maxx + minx)/2;
  center[1] = (maxy + miny)/2;
  double rheight = maxy - miny;
  double rlength = maxx - maxy;
  double A[2],B[2] ;
  int q ;
  
  G_rgb(0,0,0) ;
  G_clear() ;
  G_rgb(1,0,0) ;
  G_fill_polygon(rx,ry,8) ;
  
  G_rgb(1,1,0) ;
  G_wait_click(A) ;
  G_fill_circle(A[0],A[1],2) ;
  G_wait_click(B) ;
  G_fill_circle(B[0],B[1],2) ;
  draw_rocket(A, B, rx, ry, rheight, rlength, center);
  G_rgb(1,0,0);
  G_fill_polygon(rx, ry, 8);


  q = G_wait_key() ;
}

