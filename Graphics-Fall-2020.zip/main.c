#include <stdio.h>
#include "FPToolkit.c"
#include "my.c"

int main(void) {
  double u[10] = {100, 200, 300, 400};
  double v[10] = {300, 270, 420, 140};
  G_choose_repl_display();
  G_init_graphics(600, 600);
  my_polygon(u, v, 4);

  G_wait_key();
}

