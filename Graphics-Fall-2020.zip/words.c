#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv){
  int i;
  printf("there are %d words in\n", argc);
  for (i = 0; i < argc; i++){
    printf("%s\n", argv[i]);
  }
}



