#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "FPToolkit.c"
#include "M2d_matrix_toolsS.c"
#include "M3d_matrix_tools.c"

#define MAXPTS 9000
#define MAXPOLY 5000
#define SCREENSIZE 600
#define THETA .1
#define CENTERX 300
#define CENTERY 300
#define HALFANGLE 45 // in degrees

int numobjects;
int numpoints[10]; 
double x[10][MAXPTS]; 
double y[10][MAXPTS];
double z[10][MAXPTS];
int numpoly[10];
int psize[10][MAXPOLY];
int con[10][MAXPOLY][20]; //as many as 5000 polygons with up to 20 sides
// double red[10][MAXPOLY], grn[10][MAXPOLY], blu[10][MAXPOLY];


typedef
struct {
  int objnum ;
  int polynum ;
  double dist ;
}
THING ;

int n = 9000;
THING all_polygons[9000];

void init_array()
{
  int thing_counter = 0;
  for (int i = 0; i < numobjects; i++){
    for (int j = 0; j < numpoly[i]; j++){
      all_polygons[thing_counter].objnum = i;
      all_polygons[thing_counter].polynum = j;
      all_polygons[thing_counter].dist = z[i][con[i][j][0]];
      thing_counter++;
    }
  }
  n = thing_counter;
}

// void init_array()
// {
//   all_polygons[0].objnum  = 0 ;  all_polygons[0].polynum  = 0 ;  all_polygons[0].dist  = 8.6 ;
//   all_polygons[1].objnum  = 0 ;  all_polygons[1].polynum  = 1 ;  all_polygons[1].dist  = 3.6 ;
//   all_polygons[2].objnum  = 0 ;  all_polygons[2].polynum  = 2 ;  all_polygons[2].dist  = 4.6 ;

//   all_polygons[3].objnum  = 1 ;  all_polygons[3].polynum  = 0 ;  all_polygons[3].dist  = 2.7 ;
//   all_polygons[4].objnum  = 1 ;  all_polygons[4].polynum  = 1 ;  all_polygons[4].dist  = 5.6 ;
//   all_polygons[5].objnum  = 1 ;  all_polygons[5].polynum  = 2 ;  all_polygons[5].dist  = 4.2 ;
//   all_polygons[6].objnum  = 1 ;  all_polygons[6].polynum  = 3 ;  all_polygons[6].dist  = 3.9 ;

//   all_polygons[7].objnum  = 2 ;  all_polygons[7].polynum  = 0 ;  all_polygons[7].dist  = 4.5 ;
//   all_polygons[8].objnum  = 2 ;  all_polygons[8].polynum  = 1 ;  all_polygons[8].dist  = 6.5 ;

// }

int compare (const void *p, const void *q)
{
  THING *a, *b ;

  a = (THING*)p ;
  b = (THING*)q ;

  if  (((*a).dist) < ((*b).dist)) return -1 ;
  else if (((*a).dist) > ((*b).dist)) return 1 ;
  else return 0 ;
}



void print_mat(double a[3][3]){
  for (int r = 0; r < 3; r++){
    for (int c = 0; c < 3; c++){
      printf("%lf ", a[r][c]);
    }
    printf("\n");
  }
}

void print_arrays(double a[4], double b[4]){
  for(int i = 0; i<4; i++){
    printf("%lf ", a[i]);
  }
  printf("\n");
  for(int i = 0; i<4; i++){
    printf("%lf ", b[i]);
  }
  printf("\n");
}


void rotate(int index, double t){
  // rotation matrix
  double R[3][3];
  M2d_make_rotation_radians(R, t);
  // translation from center of the screen to origin
  double T1[3][3];
  M2d_make_translation(T1, -CENTERX, -CENTERY);
  // translation from origin to center of screen
  double T2[3][3];
  M2d_make_translation(T2, CENTERX, CENTERY);
  // store resulting matrices in m
  double m[3][3];
  // m = T2*R*T1
  M2d_mat_mult(m, T2, R);
  M2d_mat_mult(m, m, T1);
  //  |x|       |x|
  //  |y| = m * |y|
  //  |1|       |1|
  M2d_mat_mult_points(x[index], y[index], m, x[index], y[index], numpoints[index]);
}


void transform(int index){
  // translate to the origin of xyz space
  double T0[4][4];
  M3d_make_translation(T0, -x[index][numpoints[index]], -y[index][numpoints[index]], -z[index][numpoints[index]]);
  M3d_mat_mult_points(x[index], y[index], z[index], T0, x[index], y[index], z[index], numpoints[index]+1);
  
}

void readxyz(FILE *g, int index){
  double sumx = 0;
  double sumy = 0;
  double sumz = 0;
  if (fscanf(g, "%i", &numpoints[index]) != 1) (exit(0));
  for (int i = 0; i < numpoints[index]; i++){
    fscanf(g, "%lf %lf %lf", &x[index][i], &y[index][i], &z[index][i]);
    sumx+=x[index][i];
    sumy+=y[index][i];
    sumz+=z[index][i];
  }
  printf("before calculating center\n");
  x[index][numpoints[index]] = sumx/numpoints[index];
  y[index][numpoints[index]] = sumy/numpoints[index];
  z[index][numpoints[index]] = sumz/numpoints[index];
  printf("after calculating center\n");
}


void drawxy(int index){
  for (int i = 0; i < numpoints[index]; i++){
    G_fill_circle(x[index][i], y[index][i], 5);
  }
}

void readpoly(FILE *g, int index){
  if (fscanf(g, "%i", &numpoly[index]) != 1) (exit(0));
  for (int i = 0; i < numpoly[index]; i++){
    fscanf(g, "%i", &psize[index][i]);

    for (int j = 0; j < psize[index][i]; j++){
      fscanf(g, "%i", &con[index][i][j]);
    }
  }
}

// void readcolors(FILE *g, int index){
//   for (int i = 0; i < numpoly[index]; i++){
//     fscanf(g, "%lf %lf %lf", &red[index][i], &grn[index][i], &blu[index][i]);
//   }
// }

void drawpoly3d(double xp[], double yp[], double zp[], int n){
  for (int i = 0; i < n; i++){
    xp[i] = xp[i] / zp[i];
    yp[i] = yp[i] / zp[i];
  }
  double M[3][3];
  double S[3][3];
  M2d_make_translation(M, 300, 300);
  M2d_make_scaling(S, 300/tan(M_PI/4),  300/tan(M_PI/4));
  M2d_mat_mult(M, M, S);
  M2d_mat_mult_points(xp,yp, M, xp, yp, n);

  
  //G_rgb(1, 0, 0);
  G_fill_polygon(xp, yp, n);

  G_rgb(0, 0, 0);
  G_polygon(xp, yp, n);

}

void draw_single_object(int index){
  double xp[100];
  double yp[100];
  double zp[100];
  for (int i = 0; i < numpoly[index]; i++){
    for (int j = 0; j < psize[index][i]; j++){
      xp[j] = x[index][con[index][i][j]];
      yp[j] = y[index][con[index][i][j]];
      zp[j] = z[index][con[index][i][j]];
    }
    drawpoly3d(xp,yp,zp,psize[index][i]);
  }
}

void draw_all_objects(){
  double xp[100];
  double yp[100];
  double zp[100];
  for (int i = n - 1; i >= 0; i--){
    for (int j = 0; j < psize[all_polygons[i].objnum][all_polygons[i].polynum]; j++){
      xp[j] = x[all_polygons[i].objnum][con[all_polygons[i].objnum][all_polygons[i].polynum][j]];
      yp[j] = y[all_polygons[i].objnum][con[all_polygons[i].objnum][all_polygons[i].polynum][j]];
      zp[j] = z[all_polygons[i].objnum][con[all_polygons[i].objnum][all_polygons[i].polynum][j]];
    }

    if (all_polygons[i].objnum == 0){
      G_rgb(1, 0, 0);
    }
    else{
      G_rgb(0, 1, 0);
    }
    drawpoly3d(xp,yp,zp,psize[all_polygons[i].objnum][all_polygons[i].polynum]);
  }


}

void update_dist(){
  for (int i = 0; i < n; i++){
    all_polygons[i].dist = z[all_polygons[i].objnum][con[all_polygons[i].objnum][all_polygons[i].polynum][0]];
  }
}

int main(int argc, char** argv) {
  numobjects = argc - 1;
  FILE *fp;
  if (argc < 2){
    printf("Usage: pgm infiles\n");
    exit(0);
  }
  for (int i = 1; i < argc; i++){
    fp = fopen(argv[i], "r");
    if (fp == NULL){
      printf("Cannot open %s\n", argv[i]);
      exit(0);
    }
    readxyz(fp, i - 1);
    printf("finished reading points");
    readpoly(fp, i - 1);
    printf("finished reading polygons");
    // readcolors(fp, i - 1);
    // transform(i - 1);
  }

  init_array();

  printf("initialized array\n");

  qsort (all_polygons, n, sizeof(THING), compare);

  printf("sorted array\n");

  G_choose_repl_display();
  G_init_graphics(SCREENSIZE, SCREENSIZE);
  // drawxy();
  int current = -1;
  int input;
  int sign = 1;
  int action;
  // rotation matirces
  double R3dx_positive[4][4];
  M3d_make_x_rotation_cs(R3dx_positive, cos(THETA/M_PI), sin(THETA/M_PI));
  double R3dx_negative[4][4];
  M3d_make_x_rotation_cs(R3dx_negative, cos(-THETA/M_PI), sin(-THETA/M_PI));
  double R3dy_positive[4][4];
  M3d_make_y_rotation_cs(R3dy_positive, cos(THETA/M_PI), sin(THETA/M_PI));
  double R3dy_negative[4][4];
  M3d_make_y_rotation_cs(R3dy_negative, cos(-THETA/M_PI), sin(-THETA/M_PI));
  double R3dz_positive[4][4];
  M3d_make_z_rotation_cs(R3dz_positive, cos(THETA/M_PI), sin(THETA/M_PI));
  double R3dz_negative[4][4];
  M3d_make_z_rotation_cs(R3dz_negative, cos(-THETA/M_PI), sin(-THETA/M_PI));

  // translation matrices
  double T3dx_positive[4][4];
  M3d_make_translation(T3dx_positive, 1, 0, 0);
  double T3dx_negative[4][4];
  M3d_make_translation(T3dx_negative, -1, 0, 0);
  double T3dy_positive[4][4];
  M3d_make_translation(T3dy_positive, 0, 1, 0);
  double T3dy_negative[4][4];
  M3d_make_translation(T3dy_negative, 0, -1, 0);
  double T3dz_positive[4][4];
  M3d_make_translation(T3dz_positive, 0, 0, 1);
  double T3dz_negative[4][4];
  M3d_make_translation(T3dz_negative, 0, 0, -1);

  draw_all_objects() ;

  double V[4][4];
  while(1){
    M3d_make_identity (V) ;
    int q = G_wait_key();
    if (q == 0){
      continue;
    }
    
    if (q == 'q') {
      exit(0) ;

    } else if (q == 'c') {
      sign = -sign ;

    } else if (q == 't') {
      action = q ;

    } else if (q == 'r') {
      action = q ;

    } else if (('0' <= q) && (q <= '9')) {
      int k = q - '0' ;  
      if (k < numobjects) {current = k ;}

    } else if ((q == 'x') && (action == 't')) {
      // translate along x in direction sign
      if (sign > 0){
        M3d_mat_mult(V, V, T3dx_positive);
      }
      else if (sign < 0){
        M3d_mat_mult(V, V, T3dx_negative);  
      }
    } else if ((q == 'y') && (action == 't')) {
      // translate along y in direction sign
      if (sign > 0){
        M3d_mat_mult(V, V, T3dy_positive);
      }
      else if (sign < 0){
        M3d_mat_mult(V, V, T3dy_negative);  
      }
    } else if ((q == 'z') && (action == 't')) {
      // translate along z in direction sign
      if (sign > 0){
        M3d_mat_mult(V, V, T3dz_positive);
      }
      else if (sign < 0){
        M3d_mat_mult(V, V, T3dz_negative);  
      }
    } else if ((q == 'x') && (action == 'r')) {
      if (sign > 0) {
        double translator[4][4];
        M3d_make_translation(translator, -x[current][numpoints[current]], -y[current][numpoints[current]], -z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
        M3d_mat_mult(V, R3dx_positive, V);
        M3d_make_translation(translator, x[current][numpoints[current]], y[current][numpoints[current]], z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
      }
      else if (sign < 0){
        double translator[4][4];
        M3d_make_translation(translator, -x[current][numpoints[current]], -y[current][numpoints[current]], -z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
        M3d_mat_mult(V, R3dx_negative, V);
        M3d_make_translation(translator, x[current][numpoints[current]], y[current][numpoints[current]], z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
      }
      // rotate along x in direction sign
    } else if ((q == 'y') && (action == 'r')) {
      // rotate along x in direction sign
      if (sign > 0) {
        double translator[4][4];
        M3d_make_translation(translator, -x[current][numpoints[current]], -y[current][numpoints[current]], -z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
        M3d_mat_mult(V, R3dy_positive, V);
        M3d_make_translation(translator, x[current][numpoints[current]], y[current][numpoints[current]], z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
      }
      else if (sign < 0){
        double translator[4][4];
        M3d_make_translation(translator, -x[current][numpoints[current]], -y[current][numpoints[current]], -z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
        M3d_mat_mult(V, R3dy_negative, V);
        M3d_make_translation(translator, x[current][numpoints[current]], y[current][numpoints[current]], z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
      }
    } else if ((q == 'z') && (action == 'r')) {
      // rotate along x in direction sign
      if (sign > 0) {
        double translator[4][4];
        M3d_make_translation(translator, -x[current][numpoints[current]], -y[current][numpoints[current]], -z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
        M3d_mat_mult(V, R3dz_positive, V);
        M3d_make_translation(translator, x[current][numpoints[current]], y[current][numpoints[current]], z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
      }
      if (sign < 0){
        double translator[4][4];
        M3d_make_translation(translator, -x[current][numpoints[current]], -y[current][numpoints[current]], -z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
        M3d_mat_mult(V, R3dz_negative, V);
        M3d_make_translation(translator, x[current][numpoints[current]], y[current][numpoints[current]], z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
      }
    } else {
      printf("no action\n") ;
    }



    M3d_mat_mult_points (x[current],y[current],z[current],  V, x[current],y[current],z[current],numpoints[current]+1) ;

    // need to update dist of each polygon!

    update_dist();

    qsort (all_polygons, n, sizeof(THING), compare);
      // the numpoints[onum]+1 is because we have stored the center
      // of the object at the arrays' end

    G_rgb(1,1,1) ; 
    G_clear() ;
    G_rgb(0,0,1) ;
    draw_all_objects() ;
    // draw_single_object(current) ;
  }
}