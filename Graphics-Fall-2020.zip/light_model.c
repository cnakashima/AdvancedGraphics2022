#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "FPToolkit.c"
#include "M2d_matrix_toolsS.c"
#include "M3d_matrix_tools.c"

#define MAXPTS 9000
#define MAXPOLY 5000
#define SCREENSIZE 600
#define THETA .1
#define CENTERX 300
#define CENTERY 300
#define HALFANGLE 45 // in degrees

int numobjects;
int numpoints[10]; 
double x[10][MAXPTS]; 
double y[10][MAXPTS];
double z[10][MAXPTS];
int numpoly[10];
int psize[10][MAXPOLY];
int con[10][MAXPOLY][20]; //as many as 5000 polygons with up to 20 sides
// double red[10][MAXPOLY], grn[10][MAXPOLY], blu[10][MAXPOLY];
double color[10][3];


typedef
struct {
  int objnum ;
  int polynum ;
  double dist ;
}
THING ;

int n = 9000;
THING all_polygons[9000];

void init_array()
{
  int thing_counter = 0;
  for (int i = 0; i < numobjects; i++){
    for (int j = 0; j < numpoly[i]; j++){
      all_polygons[thing_counter].objnum = i;
      all_polygons[thing_counter].polynum = j;
      all_polygons[thing_counter].dist = z[i][con[i][j][0]];
      thing_counter++;
    }
  }
  n = thing_counter;
}

void set_colors(){
  color[0][0] = 1; color[0][1] = 0; color[0][2] = 0;
  color[1][0] = 0; color[1][1] = 1; color[1][2] = 0;
  color[2][0] = 0; color[2][1] = 0; color[2][2] = 1;
  color[3][0] = 1; color[3][1] = 1; color[3][2] = 0;
  color[4][0] = 1; color[4][1] = 0; color[4][2] = 1;
  color[5][0] = 1; color[5][1] = 1; color[5][2] = 1;
  color[6][0] = .5; color[6][1] = 0; color[6][2] = 0;
  color[7][0] = 0; color[7][1] = .5; color[7][2] = 0;
  color[8][0] = 0; color[8][1] = 0; color[8][2] = .5;
  color[9][0] = 1; color[9][1] = .5; color[9][2] = 0;
}

// void init_array()
// {
//   all_polygons[0].objnum  = 0 ;  all_polygons[0].polynum  = 0 ;  all_polygons[0].dist  = 8.6 ;
//   all_polygons[1].objnum  = 0 ;  all_polygons[1].polynum  = 1 ;  all_polygons[1].dist  = 3.6 ;
//   all_polygons[2].objnum  = 0 ;  all_polygons[2].polynum  = 2 ;  all_polygons[2].dist  = 4.6 ;

//   all_polygons[3].objnum  = 1 ;  all_polygons[3].polynum  = 0 ;  all_polygons[3].dist  = 2.7 ;
//   all_polygons[4].objnum  = 1 ;  all_polygons[4].polynum  = 1 ;  all_polygons[4].dist  = 5.6 ;
//   all_polygons[5].objnum  = 1 ;  all_polygons[5].polynum  = 2 ;  all_polygons[5].dist  = 4.2 ;
//   all_polygons[6].objnum  = 1 ;  all_polygons[6].polynum  = 3 ;  all_polygons[6].dist  = 3.9 ;

//   all_polygons[7].objnum  = 2 ;  all_polygons[7].polynum  = 0 ;  all_polygons[7].dist  = 4.5 ;
//   all_polygons[8].objnum  = 2 ;  all_polygons[8].polynum  = 1 ;  all_polygons[8].dist  = 6.5 ;

// }

int compare (const void *p, const void *q)
{
  THING *a, *b ;

  a = (THING*)p ;
  b = (THING*)q ;

  if  (((*a).dist) < ((*b).dist)) return -1 ;
  else if (((*a).dist) > ((*b).dist)) return 1 ;
  else return 0 ;
}



void print_mat(double a[3][3]){
  for (int r = 0; r < 3; r++){
    for (int c = 0; c < 3; c++){
      printf("%lf ", a[r][c]);
    }
    printf("\n");
  }
}

void print_arrays(double a[4], double b[4]){
  for(int i = 0; i<4; i++){
    printf("%lf ", a[i]);
  }
  printf("\n");
  for(int i = 0; i<4; i++){
    printf("%lf ", b[i]);
  }
  printf("\n");
}


void rotate(int index, double t){
  // rotation matrix
  double R[3][3];
  M2d_make_rotation_radians(R, t);
  // translation from center of the screen to origin
  double T1[3][3];
  M2d_make_translation(T1, -CENTERX, -CENTERY);
  // translation from origin to center of screen
  double T2[3][3];
  M2d_make_translation(T2, CENTERX, CENTERY);
  // store resulting matrices in m
  double m[3][3];
  // m = T2*R*T1
  M2d_mat_mult(m, T2, R);
  M2d_mat_mult(m, m, T1);
  //  |x|       |x|
  //  |y| = m * |y|
  //  |1|       |1|
  M2d_mat_mult_points(x[index], y[index], m, x[index], y[index], numpoints[index]);
}


void transform(int index){
  // translate to the origin of xyz space
  double T0[4][4];
  M3d_make_translation(T0, -x[index][numpoints[index]], -y[index][numpoints[index]], -z[index][numpoints[index]]);
  M3d_mat_mult_points(x[index], y[index], z[index], T0, x[index], y[index], z[index], numpoints[index]+1);
  
}

void readxyz(FILE *g, int index){
  double sumx = 0;
  double sumy = 0;
  double sumz = 0;
  if (fscanf(g, "%i", &numpoints[index]) != 1) (exit(0));
  for (int i = 0; i < numpoints[index]; i++){
    fscanf(g, "%lf %lf %lf", &x[index][i], &y[index][i], &z[index][i]);
    sumx+=x[index][i];
    sumy+=y[index][i];
    sumz+=z[index][i];
  }
  // printf("before calculating center\n");
  x[index][numpoints[index]] = sumx/numpoints[index];
  y[index][numpoints[index]] = sumy/numpoints[index];
  z[index][numpoints[index]] = sumz/numpoints[index];
  // printf("after calculating center\n");
}


void drawxy(int index){
  for (int i = 0; i < numpoints[index]; i++){
    G_fill_circle(x[index][i], y[index][i], 5);
  }
}

void readpoly(FILE *g, int index){
  if (fscanf(g, "%i", &numpoly[index]) != 1) (exit(0));
  for (int i = 0; i < numpoly[index]; i++){
    fscanf(g, "%i", &psize[index][i]);

    for (int j = 0; j < psize[index][i]; j++){
      fscanf(g, "%i", &con[index][i][j]);
    }
  }
}

// void readcolors(FILE *g, int index){
//   for (int i = 0; i < numpoly[index]; i++){
//     fscanf(g, "%lf %lf %lf", &red[index][i], &grn[index][i], &blu[index][i]);
//   }
// }

double dot_product(double vector1[], double vector2[]){
  return (vector1[0] * vector2[0]) + (vector1[1] * vector2[1]) + (vector1[2] * vector2[2]);
}

double intensity(double xp[], double yp[], double zp[], int n){
  // if we don't have at least 3 points there is no polygon here
  if (n < 3){
    return 0;
  }

  // set ambient
  double ambient = .2;

  // create light vector based on light position 
  double lightp[3] = {100, 200, -50};
  double lightv[3] = {lightp[0] - xp[0], lightp[1] - yp[0], lightp[2] - zp[0]}; 
  double lightmag = sqrt(lightv[0] * lightv[0] + lightv[1] * lightv[1] + lightv[2] * lightv[2]);

  // if (lightv[0] * lightv[0] + lightv[1] * lightv[1] + lightv[2] * lightv[2] <= 0) printf("lightmag nan\n");

  // make lightv a unit vector
  for (int i = 0; i < 3; i++){
    lightv[i] /= lightmag;
  }

  // form two vectors from the polygon and cross multiply to get the normal vector
  double vector1[3] = {xp[0] - xp[1], yp[0]-yp[1], zp[0]-zp[1]};
  double vector2[3] = {xp[2] - xp[1], yp[2]-yp[1], zp[2]-zp[1]};
  double normal[3] = {(vector1[1]*vector2[2]) - (vector1[2]*vector2[1]), (vector1[2]*vector2[0]) - (vector1[0]*vector2[2]), (vector1[0]*vector2[1]) - (vector1[1]*vector2[0])};
  double n_magnitude = sqrt(normal[0]*normal[0] + normal[1]*normal[1] + normal[2]*normal[2]);

  // if (normal[0]*normal[0] + normal[1]*normal[1] + normal[2]*normal[2] <= 0) printf("n_magnitude nan\n");

  for (int i = 0; i < 3; i++){
    normal[i] /= n_magnitude;
  }
  // now normal should be the normal unit vector
  // set diffuse
  double diffuse = .5 * dot_product(normal, lightv);

  // if diffuse is negative then the normal vector is pointing down so negate diffuse and all components of the normal vector
  if (diffuse < 0) {
    diffuse *= -1;
    for (int i = 0; i < 3; i++){
      normal[i] *= -1;
    }
  }

  // for eye vector using point for the eye (0, 0, 0)
  double eyept[3] = {0, 0, 0};
  double eyev[3] = {eyept[0] - xp[0], eyept[1] - yp[0], eyept[2] - zp[0]}; 
  double eyemag = sqrt(eyev[0] * eyev[0] + eyev[1] * eyev[1] + eyev[2] * eyev[2]);

  // if (eyev[0] * eyev[0] + eyev[1] * eyev[1] + eyev[2] * eyev[2] <= 0) printf("lightmag nan\n");

  // make eyev a unit vector
  for (int i = 0; i < 3; i++){
    eyev[i] /= eyemag;
  }

  // calculate the reflection vector
  double reflectcoeff = 2 * dot_product(normal, lightv);
  double reflection[3] = {(reflectcoeff * normal[0]) - lightv[0], (reflectcoeff * normal[1]) - lightv[1], (reflectcoeff * normal[2]) - lightv[2]};

  // set specular
  double specular = .3 * pow(dot_product(eyev, reflection), 50);

  // if eye is pointing downward so dot product of eyev and normal is negate, we only want ambient light
  if (dot_product(eyev, normal) < 0) {
    // printf("%lf\n", ambient);
    return ambient;
  }

  // otherwise
  // printf("%lf\n", ambient+ diffuse+specular);
  return ambient + diffuse + specular;

}

void drawpoly3d(double xp[], double yp[], double zp[], int n, int objnum){

  double intense = intensity(xp,yp,zp,n);

  for (int i = 0; i < n; i++){
    xp[i] = xp[i] / zp[i];
    yp[i] = yp[i] / zp[i];
  }
  double M[3][3];
  double S[3][3];
  M2d_make_translation(M, 300, 300);
  M2d_make_scaling(S, 300/tan(M_PI/4),  300/tan(M_PI/4));
  M2d_mat_mult(M, M, S);
  M2d_mat_mult_points(xp,yp, M, xp, yp, n);

  double rgb[3];

  if (intense < .7){
    double f = intense / .7;
    rgb[0] = intense * color[objnum][0];
    rgb[1] = intense * color[objnum][1];
    rgb[2] = intense * color[objnum][2];
  }
  else {
    double f = (intense - .7) / (1 - .7);
    rgb[0] = (intense * (1 - color[objnum][0])) + color[objnum][0];
    rgb[1] = (intense * (1 - color[objnum][1])) + color[objnum][1];
    rgb[2] = (intense * (1 - color[objnum][2])) + color[objnum][2];
  }

  G_rgb(rgb[0], rgb[1], rgb[2]);
  G_fill_polygon(xp, yp, n);

  // G_rgb(0, 0, 0);
  // G_polygon(xp, yp, n);

}

void draw_single_object(int index){
  double xp[100];
  double yp[100];
  double zp[100];
  for (int i = 0; i < numpoly[index]; i++){
    for (int j = 0; j < psize[index][i]; j++){
      xp[j] = x[index][con[index][i][j]];
      yp[j] = y[index][con[index][i][j]];
      zp[j] = z[index][con[index][i][j]];
    }
    drawpoly3d(xp,yp,zp,psize[index][i], index);
  }
}

void draw_all_objects(){
  double xp[100];
  double yp[100];
  double zp[100];
  for (int i = n - 1; i >= 0; i--){
    for (int j = 0; j < psize[all_polygons[i].objnum][all_polygons[i].polynum]; j++){
      xp[j] = x[all_polygons[i].objnum][con[all_polygons[i].objnum][all_polygons[i].polynum][j]];
      yp[j] = y[all_polygons[i].objnum][con[all_polygons[i].objnum][all_polygons[i].polynum][j]];
      zp[j] = z[all_polygons[i].objnum][con[all_polygons[i].objnum][all_polygons[i].polynum][j]];
    }
    drawpoly3d(xp,yp,zp,psize[all_polygons[i].objnum][all_polygons[i].polynum], all_polygons[i].objnum);
  }


}

void update_dist(){
  for (int i = 0; i < n; i++){
    all_polygons[i].dist = z[all_polygons[i].objnum][con[all_polygons[i].objnum][all_polygons[i].polynum][0]];
  }
}

int main(int argc, char** argv) {
  numobjects = argc - 1;
  FILE *fp;
  if (argc < 2){
    printf("Usage: pgm infiles\n");
    exit(0);
  }
  for (int i = 1; i < argc; i++){
    fp = fopen(argv[i], "r");
    if (fp == NULL){
      printf("Cannot open %s\n", argv[i]);
      exit(0);
    }
    readxyz(fp, i - 1);
    // printf("finished reading points");
    readpoly(fp, i - 1);
    // printf("finished reading polygons");
    // readcolors(fp, i - 1);
    // transform(i - 1);
  }

  init_array();

  // printf("initialized array\n");

  qsort (all_polygons, n, sizeof(THING), compare);

  // printf("sorted array\n");

  G_choose_repl_display();
  G_init_graphics(SCREENSIZE, SCREENSIZE);
  // drawxy();
  int current = -1;
  int input;
  int sign = 1;
  int action;
  // rotation matirces
  double R3dx_positive[4][4];
  M3d_make_x_rotation_cs(R3dx_positive, cos(THETA/M_PI), sin(THETA/M_PI));
  double R3dx_negative[4][4];
  M3d_make_x_rotation_cs(R3dx_negative, cos(-THETA/M_PI), sin(-THETA/M_PI));
  double R3dy_positive[4][4];
  M3d_make_y_rotation_cs(R3dy_positive, cos(THETA/M_PI), sin(THETA/M_PI));
  double R3dy_negative[4][4];
  M3d_make_y_rotation_cs(R3dy_negative, cos(-THETA/M_PI), sin(-THETA/M_PI));
  double R3dz_positive[4][4];
  M3d_make_z_rotation_cs(R3dz_positive, cos(THETA/M_PI), sin(THETA/M_PI));
  double R3dz_negative[4][4];
  M3d_make_z_rotation_cs(R3dz_negative, cos(-THETA/M_PI), sin(-THETA/M_PI));

  // translation matrices
  double T3dx_positive[4][4];
  M3d_make_translation(T3dx_positive, .5, 0, 0);
  double T3dx_negative[4][4];
  M3d_make_translation(T3dx_negative, -.5, 0, 0);
  double T3dy_positive[4][4];
  M3d_make_translation(T3dy_positive, 0, .5, 0);
  double T3dy_negative[4][4];
  M3d_make_translation(T3dy_negative, 0, -.5, 0);
  double T3dz_positive[4][4];
  M3d_make_translation(T3dz_positive, 0, 0, .5);
  double T3dz_negative[4][4];
  M3d_make_translation(T3dz_negative, 0, 0, -.5);

  set_colors();

  draw_all_objects() ;

  double V[4][4];
  while(1){
    M3d_make_identity (V) ;
    int q = G_wait_key();
    if (q == 0){
      continue;
    }
    
    if (q == 'q') {
      exit(0) ;

    } else if (q == 'c') {
      sign = -sign ;

    } else if (q == 't') {
      action = q ;

    } else if (q == 'r') {
      action = q ;

    } else if (('0' <= q) && (q <= '9')) {
      int k = q - '0' ;  
      if (k < numobjects) {current = k ;}

    } else if ((q == 'x') && (action == 't')) {
      // translate along x in direction sign
      if (sign > 0){
        M3d_mat_mult(V, V, T3dx_positive);
      }
      else if (sign < 0){
        M3d_mat_mult(V, V, T3dx_negative);  
      }
    } else if ((q == 'y') && (action == 't')) {
      // translate along y in direction sign
      if (sign > 0){
        M3d_mat_mult(V, V, T3dy_positive);
      }
      else if (sign < 0){
        M3d_mat_mult(V, V, T3dy_negative);  
      }
    } else if ((q == 'z') && (action == 't')) {
      // translate along z in direction sign
      if (sign > 0){
        M3d_mat_mult(V, V, T3dz_positive);
      }
      else if (sign < 0){
        M3d_mat_mult(V, V, T3dz_negative);  
      }
    } else if ((q == 'x') && (action == 'r')) {
      if (sign > 0) {
        double translator[4][4];
        M3d_make_translation(translator, -x[current][numpoints[current]], -y[current][numpoints[current]], -z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
        M3d_mat_mult(V, R3dx_positive, V);
        M3d_make_translation(translator, x[current][numpoints[current]], y[current][numpoints[current]], z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
      }
      else if (sign < 0){
        double translator[4][4];
        M3d_make_translation(translator, -x[current][numpoints[current]], -y[current][numpoints[current]], -z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
        M3d_mat_mult(V, R3dx_negative, V);
        M3d_make_translation(translator, x[current][numpoints[current]], y[current][numpoints[current]], z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
      }
      // rotate along x in direction sign
    } else if ((q == 'y') && (action == 'r')) {
      // rotate along x in direction sign
      if (sign > 0) {
        double translator[4][4];
        M3d_make_translation(translator, -x[current][numpoints[current]], -y[current][numpoints[current]], -z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
        M3d_mat_mult(V, R3dy_positive, V);
        M3d_make_translation(translator, x[current][numpoints[current]], y[current][numpoints[current]], z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
      }
      else if (sign < 0){
        double translator[4][4];
        M3d_make_translation(translator, -x[current][numpoints[current]], -y[current][numpoints[current]], -z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
        M3d_mat_mult(V, R3dy_negative, V);
        M3d_make_translation(translator, x[current][numpoints[current]], y[current][numpoints[current]], z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
      }
    } else if ((q == 'z') && (action == 'r')) {
      // rotate along x in direction sign
      if (sign > 0) {
        double translator[4][4];
        M3d_make_translation(translator, -x[current][numpoints[current]], -y[current][numpoints[current]], -z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
        M3d_mat_mult(V, R3dz_positive, V);
        M3d_make_translation(translator, x[current][numpoints[current]], y[current][numpoints[current]], z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
      }
      if (sign < 0){
        double translator[4][4];
        M3d_make_translation(translator, -x[current][numpoints[current]], -y[current][numpoints[current]], -z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
        M3d_mat_mult(V, R3dz_negative, V);
        M3d_make_translation(translator, x[current][numpoints[current]], y[current][numpoints[current]], z[current][numpoints[current]]);
        M3d_mat_mult(V, translator, V);
      }
    } else {
      printf("no action\n") ;
    }



    M3d_mat_mult_points (x[current],y[current],z[current],  V, x[current],y[current],z[current],numpoints[current]+1) ;

    // need to update dist of each polygon!

    update_dist();

    qsort (all_polygons, n, sizeof(THING), compare);
      // the numpoints[onum]+1 is because we have stored the center
      // of the object at the arrays' end

    G_rgb(1,1,1) ; 
    G_clear() ;
    G_rgb(0,0,1) ;
    draw_all_objects() ;
    // draw_single_object(current) ;
  }
}